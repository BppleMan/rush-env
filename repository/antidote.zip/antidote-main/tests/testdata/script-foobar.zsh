fpath+=( "$ANTIDOTE_HOME/foo/bar" )
source "$ANTIDOTE_HOME/foo/bar/bar.plugin.zsh"
