fpath+=( "$ANTIDOTE_HOME/git-AT-github.com-COLON-foo-SLASH-qux" )
source "$ANTIDOTE_HOME/git-AT-github.com-COLON-foo-SLASH-qux/qux.plugin.zsh"
