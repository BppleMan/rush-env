echo "sourcing foo/qux..."
plugins=($plugins foo/qux)
