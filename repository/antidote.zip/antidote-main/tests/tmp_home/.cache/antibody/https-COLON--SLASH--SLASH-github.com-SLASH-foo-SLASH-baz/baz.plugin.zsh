echo "sourcing foo/baz..."
plugins=($plugins foo/baz)
