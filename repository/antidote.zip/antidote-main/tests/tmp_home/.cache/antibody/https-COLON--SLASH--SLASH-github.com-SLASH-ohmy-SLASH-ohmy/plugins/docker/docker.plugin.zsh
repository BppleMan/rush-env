echo "sourcing docker.plugin.zsh..."
plugins+=(ohmy:docker)
