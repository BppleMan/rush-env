echo "sourcing ohmy/lib/lib2.zsh..."
libs=($libs ohmy:lib2)
