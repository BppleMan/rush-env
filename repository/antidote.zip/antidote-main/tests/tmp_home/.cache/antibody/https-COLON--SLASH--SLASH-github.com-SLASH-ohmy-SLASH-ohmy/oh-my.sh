echo "sourcing oh-my.sh..."
plugins=($plugins ohmy/ohmy)
