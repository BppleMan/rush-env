echo "sourcing ohmy/lib/lib3.zsh..."
libs=($libs ohmy:lib2)
