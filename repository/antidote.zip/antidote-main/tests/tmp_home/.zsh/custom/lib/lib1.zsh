echo "sourcing custom lib1.zsh..."
libs=($libs custom:lib1)
