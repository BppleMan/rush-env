echo "sourcing fakeuser/fakerepo..."
plugins=($plugins fakeuser/fakerepo)
