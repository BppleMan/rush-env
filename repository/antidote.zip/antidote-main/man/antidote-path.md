---
title: antidote-path
section: 1
header: Antidote Manual
---

# NAME

**antidote path** - print the path of a cloned bundle

# SYNOPSIS

| antidote path \<bundle\>

# DESCRIPTION

**antidote-path** prints the path of a cloned bundle.

# OPTIONS

-h, \--help
:   Show the help documentation.

[\<bundle\>]
:   The bundle whose cloned path will be printed.
